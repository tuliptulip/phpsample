<?php
define('FRESMS_BASE_URL', 'http://localhost/freesms_dev');
define('DATABASE_NAME', 'crcdb');
define('MYSQL_ROOT_PASSWORD', 'ewigkeit');
define('USER_NAME', 'bogdan');
define('USER_PASSWORD', 'ewigkeit');
?>
