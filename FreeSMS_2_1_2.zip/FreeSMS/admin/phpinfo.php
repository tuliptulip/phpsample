<?php
  phpinfo();
  echo "input point";
?>
